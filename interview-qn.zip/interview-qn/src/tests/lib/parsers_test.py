# Example test of parser
class TestParser:
  pass
