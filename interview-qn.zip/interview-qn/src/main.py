from abc import ABC
from typing import List

from lib.clients import BaseLogClient, ProdLogClient
from lib.entities import ActivityLog, EntityType, ActivityType


class ActivityLogIngester(ABC):
 def __init__(self, client: BaseLogClient, **kwargs):
   self.client = client
 
 def parse_data(self) -> List[ActivityLog]:
  return None

if __name__ == "__main__":
  credentials="CREDENTIALS"
  client = ProdLogClient(credentials=credentials)
  ingester = ActivityLogIngester(client=client)

  activity_logs = ingester.parse_data()
  assert activity_logs is not None

  user_activities = [
    activity_log for activity_log in activity_logs if activity_log.entity_type == EntityType.USER and activity_log.activity_type == ActivityType.ADD
  ]

  assert len(user_activities) > 0

  for log in activity_logs:
    print(str(log))